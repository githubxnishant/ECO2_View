document.getElementById('sendButton').addEventListener('click', async () => {
    const messageInput = document.getElementById('messageInput');
    const chatbox = document.getElementById('chatbox');
    const message = messageInput.value;

    if (message.trim() === '') return;

    // Display user message
    chatbox.innerHTML += `<div>User: ${message}</div>`;
    messageInput.value = '';

    // Call OpenAI API
    try {
        const response = await fetch('https://api.openai.com/v1/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer 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`
            },
            body: JSON.stringify({
                model: 'text-davinci-003',
                prompt: message,
                max_tokens: 50
            })
        });

        const data = await response.json();
        const reply = data.choices[0].text.trim();

        // Display bot message
        chatbox.innerHTML += `<div>Bot: ${reply}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight; // Scroll to the bottom
    } catch (error) {
        console.error('Error:', error);
        chatbox.innerHTML += `<div>Bot: Sorry, something went wrong.</div>`;
        chatbox.scrollTop = chatbox.scrollHeight; // Scroll to the bottom
    }
});
document.getElementById('carbonForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const electricityUsage = parseFloat(document.getElementById('electricityUsage').value);
    const gasUsage = parseFloat(document.getElementById('gasUsage').value);
    const milesDriven = parseFloat(document.getElementById('milesDriven').value);

    // Carbon emission factors (in kg CO2 per unit)
    const electricityFactor = 0.233; // kg CO2 per kWh (example value)
    const gasFactor = 5.3; // kg CO2 per therm (example value)
    const carFactor = 0.411; // kg CO2 per mile (example value)

    // Calculate carbon emissions
    const electricityEmissions = electricityUsage * electricityFactor;
    const gasEmissions = gasUsage * gasFactor;
    const carEmissions = milesDriven * carFactor;

    // Total emissions
    const totalEmissions = electricityEmissions + gasEmissions + carEmissions;

    // Display results
    document.getElementById('result').innerHTML = `
        <h2>Your Carbon Footprint</h2>
        <p>Electricity Usage: ${electricityEmissions.toFixed(2)} kg CO2</p>
        <p>Gas Usage: ${gasEmissions.toFixed(2)} kg CO2</p>
        <p>Car Travel: ${carEmissions.toFixed(2)} kg CO2</p>
        <p><strong>Total Carbon Footprint: ${totalEmissions.toFixed(2)} kg CO2</strong></p>
    `;
});

