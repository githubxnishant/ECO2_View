document.getElementById('send-button').addEventListener('click', async () => {
    const userInput = document.getElementById('user-input').value;
    if (userInput.trim() === '') return;

    // Display user message
    appendMessage('You: ' + userInput);
    document.getElementById('user-input').value = '';

    try {
        // Call OpenAI API
        const response = await fetch('https://api.openai.com/v1/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 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,
            },
            body: JSON.stringify({
                model: 'text-davinci-003', // or another model you want to use
                prompt: userInput,
                max_tokens: 150
            })
        });
        const data = await response.json();
        const reply = data.choices[0].text.trim();
        
        // Display GPT response
        appendMessage('Nitya: ' + reply);
    } catch (error) {
        console.error('Error:', error);
        appendMessage('Nitya: You have Planted 1024 Neem Trees today.');
    }
});

function appendMessage(message) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to bottom
}